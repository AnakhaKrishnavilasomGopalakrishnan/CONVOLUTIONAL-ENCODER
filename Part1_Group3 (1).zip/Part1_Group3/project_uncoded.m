% ======================================================================= %
% SSY125 Project
% ======================================================================= %
clc

% ======================================================================= %
% Simulation Options
% ======================================================================= %
N = 1e5;  % Simulate N bits each transmission (one block)
maxNumErrs = 100; % Get at least 100 bit errors (more is better)
maxNum = 1e6; % OR stop if maxNum bits have been simulated
EbN0 = -1:8; % Power efficiency range [dB]
% ======================================================================= %
% Other Options
% ======================================================================= %
% ...
% ======================================================================= %
% Simulation Chain
% ======================================================================= %
BER_uc = zeros(1, length(EbN0)); % pre-allocate a vector for BER results
for i = 1:length(EbN0) % use parfor ('help parfor') to parallelize  
  totErr = 0;  % Number of errors observed
  num = 0; % Number of bits processed
  while((totErr < maxNumErrs) && (num < maxNum))
      % ================================================================= %
      % Begin processing one block of information
      % ================================================================= %
  
      % [SRC] Generate N information bits %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      %u = randi([0 1],1,N); % Information bits

      % [ENC] Convolutional encoder 
      % Uncoded system

      % [MOD] Symbol mapper (QPSK, Gray mapping) %%%%%%%%%%%%%%%%%%%%%%%%%%
      const = [(+1+1j),(+1-1j),(-1+1j),(-1-1j)]/sqrt(2); % [X1,X2,X4,X3]
      bpsymb = log2(length(const));
      m = buffer(u, bpsymb)'; % Group bits into bits per symbol (rows correspond to one symbol's bits)
      %m_idx = bi2de(m, 'left-msb',2)'+1; % Bits to symbol index
      m_idx = bit2int(m',2)+1; % Bits to symbol index
      x_tx = const(m_idx); % Look up symbols using the indices

      % [CHA] Add Gaussian noise %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      Lx = length(x_tx); % Length of transmitted vector x_tx
      Es = sum(abs(x_tx).^2)/Lx; % Calculate the power in vector x_tx
      EbN0_lin = 10^(EbN0(i)/10);
      SNR = EbN0_lin*log2(length(const)); % SNR_lin = Es/N0 = Eb/N0*log2(M)
      N0 = Es./SNR; % Noise spectral density N0 (inf for /0)

      % As x_tx is complex, add complex noise to the signal:
      n_sigma = sqrt(N0/2); % St.dev. for AWGN noise (complex x_tx)
      n = n_sigma*(randn(1,Lx)+1j*randn(1,Lx)); % Complex noise (different Eb/N0 for the rows)
      y_rx = x_tx+n; % Received signal (after channel/noise)
      % The rows in y_rx correspond to different Eb/N0

      %Scatterplot: 
      %figure();
      %plot(y_rx, '.'); hold on;
      %plot(const,'g.');

      % [HR] Hard Receiver %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

      % Minimum Eucledian distance detector (Received symbols to bits)
      A = repmat(transpose(y_rx),1,4); % Matrix copy of y_rx
      B = repmat(const, length(y_rx),1); % Corresponding matrix of const
      metric = abs(A-B).^2; % Compute the distance to each possible symbol
      [tmp, m_hat] = min(metric, [], 2); % Find min distance m_hat
      %y_cb = de2bi(m_hat'-1,'left-msb',2)'; % Received code bits (matrix)
      y_cb = int2bit(m_hat'-1,2); % Received code bits (matrix)
      x = y_cb(:)'; % Received bits (vector)

      % Viterbi Algorithm
      % Uncoded system

      % [SR] Soft Receiver

      % ================================================================= %
      % End processing one block of information
      % ================================================================= %
      BitErrs = sum(abs(x-u)); % Count the bit errors and evaluate the bit error rate
      totErr = totErr + BitErrs;
      num = num + N; 
      disp(['+++ ' num2str(totErr) '/' num2str(maxNumErrs) ' errors. '...
          num2str(num) '/' num2str(maxNum) ' bits. Projected error rate = '...
          num2str(totErr/num, '%10.1e') '. +++']);
  end 
  BER_uc(i) = totErr/num; % Y-axis for plot
end
% ======================================================================= %
% End
% ======================================================================= %

figure(2)
semilogy(EbN0,BER_uc,'b*-')
xlabel('E_b/N_0 [dB]')
ylabel('BER')
title('Simulated Bit Error Rate')
legend('QPSK')
%%%%%%%%%%%%%%%%%%%%%% Support Functions %%%%%%%%%%%%%%%%%%%%

function c = c_calc(u, s1, s2, g) % Calculate c from u 
  c = mod(u*g(1)+s1*g(2)+s2*g(3),2);
end

function sn = state_number(s1, s2) % Convert from s1,s2 to state number
    sn = s1 + 2 * s2 + 1;
end

function s1 = s1_from_state(sn) % Convert from state number to s1
    s1 = mod(sn-1,2);
end

function s2 = s2_from_state(sn) % Convert from state number to s2
    s2 = mod(floor((sn-1)/2),2);
end
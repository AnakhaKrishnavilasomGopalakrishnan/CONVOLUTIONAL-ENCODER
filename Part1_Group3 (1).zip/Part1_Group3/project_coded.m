% ======================================================================= %
% SSY125 Project
% ======================================================================= %
clc
clear
% ======================================================================= %
% Simulation Options
% ======================================================================= %
N = 1e5;  % Simulate N bits each transmission (one block)
maxNumErrs = 100*1; % Get at least 100 bit errors (more is better)
maxNum = 1e6*1; % OR stop if maxNum bits have been simulated
EbN0 = -1:8; % Power efficiency range [dB]
% ======================================================================= %
% Other Options
% ======================================================================= %
% ...
% ======================================================================= %
% Simulation Chain
% ======================================================================= %
BER = zeros(1, length(EbN0)); % pre-allocate a vector for BER results
for i = 1:length(EbN0) % use parfor ('help parfor') to parallelize  
  totErr = 0;  % Number of errors observed
  num = 0; % Number of bits processed
  while((totErr < maxNumErrs) && (num < maxNum))
      % ================================================================= %
      % Begin processing one block of information
      % ================================================================= %
  
      % [SRC] Generate N information bits %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      u = randi([0 1],1,N); % Information bits

      % [ENC] Convolutional encoder %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      K = 2; % The encoder maps 1 input bit into 2 output bits
      g1 = [1,0,1]; g2 = [1,1,1]; % Encoder 1: G=(1+D^2,1+D+D^2)
      u = [u,0,0]; % Terminate in zero-state
      s = [0,0,u]; % Initialize in zero-state
      for k=1:length(u)
          s2=s(k); s1=s(k+1); 
          c1(k) = c_calc(u(k), s1, s2, g1);
          c2(k) = c_calc(u(k), s1, s2, g2);
      end
      c = [c1;c2]';

      % [MOD] Symbol mapper (QPSK, Gray mapping) %%%%%%%%%%%%%%%%%%%%%%%%%%
      const = [(+1+1j),(+1-1j),(-1+1j),(-1-1j)]/sqrt(2); % [X1,X2,X4,X3]
      %m_idx = bi2de(c, 'left-msb',2)'+1; % Bits to symbol index
      m_idx = bit2int(c',2)+1; % Bits to symbol index
      x_tx = const(m_idx); % Look up symbols using the indices

      % [CHA] Add Gaussian noise %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      Lx = length(x_tx); % Length of transmitted vector x_tx
      Es = sum(abs(x_tx).^2)/(Lx/K); % Calculate symbol energy for x_tx
      EbN0_lin = 10^(EbN0(i)/10); % Convert EbN0 to linear scale
      SNR = EbN0_lin*log2(length(const)); % SNR_lin = Es/N0 = Eb/N0*log2(M)
      N0 = Es./SNR; % Noise spectral density N0 (inf for /0)

      % As x_tx is complex, add complex noise to the signal:
      n_sigma = sqrt(N0/2); % St.dev. for AWGN noise (complex x_tx)
      n = n_sigma*(randn(1,Lx)+1j*randn(1,Lx)); % Complex noise
      y_rx = x_tx+n; % Received signal (after channel/noise)
      % The rows in y_rx correspond to different Eb/N0

      %Scatterplot: 
      %figure();
      %plot(y_rx, '.'); hold on;
      %plot(const,'g.');

      % [HR] Hard Receiver %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

      % Minimum Eucledian distance detector (Received symbols to bits)
      A = repmat(transpose(y_rx),1,4); % Matrix copy of y_rx
      B = repmat(const, length(y_rx),1); % Corresponding matrix of const
      metric = abs(A-B).^2; % Compute the distance to each possible symbol
      [tmp, m_hat] = min(metric, [], 2); % Find min distance m_hat
      %y_cb = de2bi(m_hat'-1,'left-msb',2)'; % Received code bits (matrix)
      y_cb = int2bit(m_hat'-1,2); % Received code bits (matrix)
      y1 = y_cb(1,:); % Received c1 after noise
      y2 = y_cb(2,:); % Received c2 after noise

       %%%%%%%%%%%%%%%%%%%%%% Viterbi Algorithm %%%%%%%%%%%%%%%%%%%%%%%%%%%%

      % Initialize variables 
      no_states = length(const); % Given by constellation
      timeframe = length(y1); % Length of input + 2
      min_error = ones(no_states, timeframe) * inf; % Holds min error in trellis
      prior_state = zeros(no_states, timeframe); % Where each min came from
      % x_in = zeros(no_states, timeframe); % What signal brought it there (s1)
      s1_in = zeros(no_states, timeframe); % State s1
      s2_in = zeros(no_states, timeframe); % State s2

      % Build the trellis diagram
      for t = 0:timeframe-1 % Go through the timeline
          if t == 0
              max_state = 1; % Only allow a start in the first state
          else
              max_state = no_states; % Else go through all of them
          end
  
          for sn = 1:max_state % Go through each state and generate paths
              % Get current state
              s1_current = s1_from_state(sn); % x(n-1), LSB of state number
              s2_current = s2_from_state(sn); % x(n-2), MSB of state
  
              for x = 0:1 % Test both possible inputs
                  if t == 0
                      current_error = 0;
                  else
                      current_error = min_error(sn,t);
                  end
  
                  if current_error < inf % Are we in an allowed state?
                  
                      % Calcultate next trellis point given x and current state
                      next_c1 = c_calc(x, s1_current, s2_current, g1);
                      next_c2 = c_calc(x, s1_current, s2_current, g2);
                      next_state = state_number(x, s1_current);
  
                      % Compare to received signal
                      added_error = abs(next_c1-y1(t+1))+abs(next_c2-y2(t+1));
                      total_error = current_error + added_error;
  
                      % Check if it is the lowest error + handle
                      if total_error < min_error(next_state, t+1) % Check for min
                          % If we end up here, current path is best
                          min_error(next_state, t+1) = total_error;
                          % x_in(next_state, t+1) = x;
                          prior_state(next_state, t+1) = sn;
                          s1_in(next_state, t+1) = x;
                          s2_in(next_state, t+1) = s1_current;
                      end
                  end
              end
          end
      end

      % Backtrack best path
      s = [1]; % 00 state
      t = timeframe;
      state = [];
      x = []; % (u_hat)
      while t > 0
          state = [s, state]; % Prepend s to state list
          x = [s1_in(s,t), x]; % Prepend x to x list
          s = prior_state(s,t); % Change to prior state
          t = t-1; % Next earlier time step
      end

      % [SR] Soft Receiver

      % ================================================================= %
      % End processing one block of information
      % ================================================================= %
      BitErrs = sum(abs(x-u)); % Count the bit errors and evaluate the bit error rate
      totErr = totErr + BitErrs;
      num = num + N; 
      disp(['+++ ' num2str(totErr) '/' num2str(maxNumErrs) ' errors. '...
          num2str(num) '/' num2str(maxNum) ' bits. Projected error rate = '...
          num2str(totErr/num, '%10.1e') '. +++']);
  end 
  BER(i) = totErr/num; % Y-axis for plot
end
% ======================================================================= %
% End
% ======================================================================= %

figure(1)
semilogy(EbN0,BER,'r*-')
xlabel('E_b/N_0 [dB]')
ylabel('BER')
title('Simulated Bit Error Rate')
legend('QPSK')
%%%%%%%%%%%%%%%%%%%%%% Support Functions %%%%%%%%%%%%%%%%%%%%

function c = c_calc(u, s1, s2, g) % Calculate c from u 
  c = mod(u*g(1)+s1*g(2)+s2*g(3),2);
end

function sn = state_number(s1, s2) % Convert from s1,s2 to state number
    sn = s1 + 2 * s2 + 1;
end

function s1 = s1_from_state(sn) % Convert from state number to s1
    s1 = mod(sn-1,2);
end

function s2 = s2_from_state(sn) % Convert from state number to s2
    s2 = mod(floor((sn-1)/2),2);
end
close all

% Instructions on how to plot the simulated results:
% 1) Run project_coded.m
% 2) Run project_uncoded.m
% 3) Run project_plots.m (this m-file)

figure(3)
semilogy(EbN0,BER,'r*-')
hold on; 
semilogy(EbN0,BER_uc,'b*-')
xlabel('E_b/N_0 [dB]')
ylabel('BER')
ylim([1e-4 1])
title('Simulated Bit Error Rate')
legend('Coded','Uncoded')
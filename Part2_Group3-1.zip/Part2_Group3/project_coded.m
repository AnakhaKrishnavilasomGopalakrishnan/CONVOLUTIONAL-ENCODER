% ======================================================================= %
% SSY125 Project
% ======================================================================= %
clc
%clear
% ======================================================================= %
% Simulation Options
% ======================================================================= %
N = 1e5;  % Simulate N bits each transmission (one block)
maxNumErrs = 100*1; % Get at least 100 bit errors (more is better)
maxNum = 1e6*1; % OR stop if maxNum bits have been simulated
EbN0 = -1:10; % Power efficiency range [dB]
% ======================================================================= %
% Other Options
% ======================================================================= %

% SPECIFY ENCODER: 
case_encoder = 4; % 1 = e1, 2 = e2, 3 = e3, 4 = e4

% SPECIFY CONSTELLATION: 
case_constellation = 3; % 1 = BPSK, 2 = QPSK, 3 = AMPM

% SPECIFY RECEIVER:
hard_detection = false;

switch case_encoder 
    case 1 % e1
        A = [0 1; 0 0];
        B = [0; 1];
        C = [1 0; 1 1];
        D = [1; 1];
    case 2 % e2
        A = [0 1 0 0; 0 0 1 0; 0 0 0 1; 0 0 0 0];
        B = [0; 0; 0; 1];
        C = [1 1 1 0; 0 1 1 0];
        D = [1; 1];
    case 3 % e3
        A = [0 1 0 0; 0 0 1 0; 0 0 0 1; 0 0 0 0];
        B = [0; 0; 0; 1];
        C = [1 1 0 0; 1 1 0 1];
        D = [1; 1];
    case 4 % e4
        A = [0 1 0; 0 0 1; 1 0 0];
        B = [1 0; 0 1; 0 0];
        C = [1 0 0; 0 0 0; 0 0 0];
        D = [0 0; 1 0; 0 1];
    otherwise 
        disp('Error: Unknown encoder')
        return;
end

switch case_constellation
    case 1 % BPSK (0->1, 1->-1)
        %const = [+1,-1];
        const = [(+1+1j),(+1-1j),(-1+1j),(-1-1j)]; % Represents c1,c2
        M = length(const);
    case 2 % QPSK (Gray mapping)
        const = [(+1+1j),(+1-1j),(-1+1j),(-1-1j)]/sqrt(2);
        M = length(const);
    case 3 % AMPM
        a = 1/sqrt(10); a3 = a*3; % Scaling a for Es=1
        const = [(a-1j*a),(-a3+1j*a3),(a+1j*a3),(-a3-1j*a),(a3-1j*a3),(-a+1j*a),(a3+1j*a),(-a-1j*a3)];
        M = length(const);
            otherwise
        disp('Error: Unknown constellation');
    return;
end

% Define constants:
state_variables  = size(A,1); % Number of state variables  (# rows in A)
signal_variables = size(B,2); % Number of signal variables (# cols in B)
c_codes = size(C,1);
Rc = signal_variables/c_codes; % size(B,2)/size(C,1);
% Constants for conversion to / from binary:
w  = [1 2 4 8 16 32 64]; % Works for up to 7 bit numbers, add for more
ws = w(1:state_variables); wu = w(1:signal_variables);
% Generate message and codes:
u_max = 2^signal_variables-1; % message is 0 to u_max
s_max = 2^state_variables;    % states numbers go from 1 to #

% ======================================================================= %
% Simulation Chain
% ======================================================================= %
BER = zeros(1, length(EbN0)); % pre-allocate a vector for BER results
for i = 1:length(EbN0) % use parfor ('help parfor') to parallelize  
  totErr = 0;  % Number of errors observed
  num = 0; % Number of bits processed
  while((totErr < maxNumErrs) && (num < maxNum))
      % ================================================================= %
      % Begin processing one block of information
      % ================================================================= %
      
      % [SRC] Generate N information bits %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      %u = randi([0 1],1,N); % Information bits
      u = randi([0 u_max], 1, N); % Generate random message
      message_length = N;
      u = [u,zeros(1,state_variables)]; % Pad with zeros at the end
      N = N + state_variables; % Message length after padding

      % [ENC] Convolutional encoder %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      c_sent = encoder(A,B,C,D,u,wu,N);

      % [MOD] Symbol mapper %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      x_tx = symbol_mapper(c_sent,const);

      % [CHA] Add Gaussian noise %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      y_rx = add_awgn_noise(x_tx, EbN0,i,Rc,M);

      % [HSR] Hard/Soft Receiver %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

      if hard_detection % Minimum Eucledian distance detector (Received symbols to bits)
          A_mat = repmat(transpose(y_rx),1,M); % Matrix copy of y_rx
          B_mat = repmat(const, length(y_rx),1); % Corresponding matrix of const
          metric = abs(A_mat-B_mat).^2; % Compute the distance to each possible symbol
          [~, m_hat] = min(metric, [], 2); % Find min distance m_hat
          c_hat = int2bit(m_hat'-1,log2(M)); % Received code bits (matrix)
      else
          c_hat = 0;
      end

      %%%%%%%%%%%%%%%%%%%%%% Viterbi Algorithm %%%%%%%%%%%%%%%%%%%%%%%%%%%%
      [x_bits,u_bits,x] = viterbi(A,B,C,D,c_hat,y_rx,N,hard_detection,u,const,message_length);

      % ================================================================= %
      % End processing one block of information
      % ================================================================= %
      BitErrs = sum(abs(x_bits-u_bits),'all'); % Count the bit errors and evaluate the bit error rate
      totErr = totErr + BitErrs;
      num = num + N; 
      disp(['+++ ' num2str(totErr) '/' num2str(maxNumErrs) ' errors. '...
          num2str(num) '/' num2str(maxNum) ' bits. Projected error rate = '...
          num2str(totErr/num, '%10.1e') '. +++']);
  end 
  BER(i) = totErr/num; % Y-axis for plot
end
% ======================================================================= %
% End
% ======================================================================= %

%A_BER_hd = BER;
%A_BER_sd = BER;
%B_BER_e1 = BER;
%B_BER_e2 = BER;
%B_BER_e3 = BER;
%C_BER_s1_sd = BER;
%C_BER_s2_sd = BER;
%C_BER_s3_sd = BER;
figure(1)
semilogy(EbN0,BER,'r*-')
xlabel('E_b/N_0 [dB]')
ylabel('BER')
ylim([1e-4 1])
title('Simulated Bit Error Rate')
legend('Coded, Hard detection')

%%%%%%%%%%%%%%%%%%%%%% Support Functions %%%%%%%%%%%%%%%%%%%%

function c_sent = encoder(A,B,C,D,u,wu,N)
   c_sent = zeros(size(C,1),N); s = zeros(size(A,1),1);
    for n = 1:N
        u_vec = bitand(wu,u(n))' > 0;          % Split signal into bits
        c_sent(:,n) = mod(C * s + D * u_vec,2);
        s = mod(A * s + B * u_vec,2);
    end
end

function x_tx = symbol_mapper(c_sent,const)
    m_idx = bit2int(c_sent,length(c_sent(:,1)))+1; % Bits to symbol index
    x_tx = const(m_idx); % Look up symbols using the indices
end

function y_rx = add_awgn_noise(x_tx, EbN0,i,Rc,M)
    Lx = length(x_tx); % Length of transmitted vector x_tx
    Es = sum(abs(x_tx).^2)/(Lx*Rc); % Calculate symbol energy for x_tx
    %Es = sum(abs(x_tx).^2)/(Lx); % Calculate symbol energy for x_tx
    EbN0_lin = 10^(EbN0(i)/10); % Convert EbN0 to linear scale
    SNR = EbN0_lin*log2(M); % SNR_lin = Es/N0 = Eb/N0*log2(M)
    N0 = Es./SNR; % Noise spectral density N0 (inf for /0)
    if isreal(x_tx)
        n_sigma = sqrt(N0); % St.dev. for AWGN noise (real x_tx)
        n = n_sigma*randn(1,Lx); % Real noise
    else
        n_sigma = sqrt(N0/2); % St.dev. for AWGN noise (complex x_tx)
        n = n_sigma*(randn(1,Lx)+1j*randn(1,Lx)); % Complex noise
    end
    y_rx = x_tx+n; % Received signal (after channel/noise)
end

function [x_bits,u_bits,x] = viterbi(A,B,C,D,c_hat,y_rx,N,hard_detection,u,const,message_length)
    % Define constants:
    state_variables  = size(A,1); % Number of state variables  (# rows in A)
    signal_variables = size(B,2); % Number of signal variables (# cols in B)
    c_codes = size(C,1);
    % Constants for conversion to / from binary:
    w  = [1 2 4 8 16 32 64]; % Works for up to 7 bit numbers, add for more
    ws = w(1:state_variables); wu = w(1:signal_variables);
    % Generate message and codes:
    u_max = 2^signal_variables-1;            % message is 0 to u_max
    s_max = 2^state_variables;               % states numbers go from 1 to #
    % Initialize variables:
    trellis_error = ones(s_max,N)*inf;
    trellis_x     = zeros(s_max,N);
    trellis_prev  = zeros(s_max,N);
    % Build the trellis diagram:
    for n = 0:N-1
        if n == 0
            states = [1];
        else
            states = 1:s_max;
        end
        for sn = states % sn = state number
            if n == 0   % n == 0 is first node (not in table)
                current_state = zeros(state_variables,1);
                current_error = 0;
            else
                current_state = bitand(ws,sn-1)' > 0; % State variables from sn
                current_error = trellis_error(sn,n);  % Error so far along path
            end
            if  current_error < inf % Is this node valid (has been reached)?
                for x_test = 0:u_max % Test all possible messages
                    x_vec = bitand(wu,x_test)' > 0; % split signal into bits
                    next_state = mod(A * current_state + B * x_vec,2);
                    next_sn = sum(next_state' .* ws) + 1; % state to state no
                    test_c = mod(C * current_state + D * x_vec,2);
                    if hard_detection
                        added_error = sum(abs(test_c-c_hat(:,n+1)));
                    else % Soft detection
                        % Change this to soft detection added error
                        test_c_idx = bit2int(test_c,length(test_c(:,1)))+1;
                        added_error = sum(abs(const(test_c_idx)-y_rx(:,n+1)));
                    end
                    total_error = current_error + added_error;
                    % disp(['Step: ', num2str(n,0), '  State: ', num2str(sn,0),' x: ', num2str(x_test,0) ' Next state: ', num2str(next_sn,0), ' Total error: ', num2str(total_error,2), ' test_c: ', num2str(test_c'), ' c_hat: ',num2str(c_hat(:,n+1)')])
                    if total_error < trellis_error(next_sn, n+1)
                        % Better path found!
                        trellis_error(next_sn, n+1) = total_error;
                        trellis_prev(next_sn, n+1) = sn;  % Link back to current state
                        trellis_x(next_sn, n+1) = x_test; % The message that caused path
                    end
                end
            end
        end
    end
    % Backtrack best path:
    [min_error, ix] = min(trellis_error(:,N)); x = []; n = N;
    while n > 0
        x = [trellis_x(ix,n), x];
        ix = trellis_prev(ix,n);
        n = n-1;
    end
    x = x(1:message_length); % Remove padding at end
    u = u(1:message_length);
    for n = 1:message_length
        x_bits(:,n) = bitand(wu,x(n))' > 0;
        u_bits(:,n) = bitand(wu,u(n))' > 0;
    end
end
clc
Rc = 1/2;
trellis1 = poly2trellis(3,[5,7]);        %    101 ,    111
trellis2 = poly2trellis(5,[27,26]);      % 10 111 , 10 110
trellis3 = poly2trellis(5,[23,33]);      % 10 011 , 11 011
trellis4 = poly2trellis([4 4],[11 10 10; 13 10 10],[17 17]);
% c1:  1 001 ,  1 011 , 0 111
% c2:  1 000
% c3:  1 000
% f :  1 111

N = 10; EbN0 = 0:10; %EbN0_lin = 10^(EbN0(i)/10); % Convert EbN0 to linear scale

spect = distspec(trellis1,N); % SPECIFY which trellis to use
d = spect.dfree:(spect.dfree+N-1);
Pb_soft = zeros(length(EbN0),1);
for i = 1:length(EbN0)
    Pb_soft(i) = sum(spect.weight.*qfunc(sqrt(2*d*Rc*10^(EbN0(i)/10))));
end
%A_BER_sd_ub = Pb_soft;
%A_BER_e1_ub = Pb_soft;
%A_BER_e2_ub = Pb_soft;
%A_BER_e3_ub = Pb_soft;

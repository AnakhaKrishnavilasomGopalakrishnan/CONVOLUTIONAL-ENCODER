% ======================================================================= %
% SSY125 Project
% ======================================================================= %
clc
%clear
% ======================================================================= %
% Simulation Options
% ======================================================================= %
N = 1e5;  % Simulate N bits each transmission (one block)
maxNumErrs = 100*1; % Get at least 100 bit errors (more is better)
maxNum = 1e6*1; % OR stop if maxNum bits have been simulated
EbN0 = -1:10; % Power efficiency range [dB]
% ======================================================================= %
% Other Options
% ======================================================================= %

% SPECIFY CONSTELLATION: 
case_constellation = 3; % 1 = BPSK, 2 = QPSK, 3 = AMPM

switch case_constellation
    case 1 % BPSK (0->1, 1->-1)
        const = [+1,-1];
        M = length(const);
    case 2 % QPSK (Gray mapping)
        const = [(+1+1j),(+1-1j),(-1+1j),(-1-1j)]/sqrt(2);
        M = length(const);
    case 3 % AMPM
        a = 1/sqrt(10); a3 = a*3; % Scaling a for Es=1
        const = [(a-1j*a),(-a3+1j*a3),(a+1j*a3),(-a3-1j*a),(a3-1j*a3),(-a+1j*a),(a3+1j*a),(-a-1j*a3)];
        M = length(const);
            otherwise
        disp('Error: Unknown constellation');
    return;
end

% ======================================================================= %
% Simulation Chain
% ======================================================================= %
BER = zeros(1, length(EbN0)); % pre-allocate a vector for BER results
for i = 1:length(EbN0) % use parfor ('help parfor') to parallelize  
  totErr = 0;  % Number of errors observed
  num = 0; % Number of bits processed
  while((totErr < maxNumErrs) && (num < maxNum))
      % ================================================================= %
      % Begin processing one block of information
      % ================================================================= %
      
      % [SRC] Generate N information bits %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      u = randi([0 1],1,N); % Information bits

      % [MOD] Symbol mapper %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      x_tx = symbol_mapper(u,const);

      % [CHA] Add Gaussian noise %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      y_rx = add_awgn_noise(x_tx, EbN0,i,M);

      % [R] Receiver %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

      % Minimum Eucledian distance detector (Received symbols to bits)
      A_mat = repmat(transpose(y_rx),1,M); % Matrix copy of y_rx
      B_mat = repmat(const, length(y_rx),1); % Corresponding matrix of const
      metric = abs(A_mat-B_mat).^2; % Compute the distance to each possible symbol
      [~, m_hat] = min(metric, [], 2); % Find min distance m_hat
      c_hat = int2bit(m_hat'-1,log2(M)); % Received code bits (matrix)
      u_hat = reshape(c_hat,1,[]); % Received code bits (row vector)
      u_hat = u_hat(1:N); % Remove zero padding at end

      %%%%%%%%%%%%%%%%%%%%%% Viterbi Algorithm %%%%%%%%%%%%%%%%%%%%%%%%%%%%
      message_bit_errors = sum(abs(u_hat-u),'all');

      % ================================================================= %
      % End processing one block of information
      % ================================================================= %
      BitErrs = message_bit_errors; % Count the bit errors and evaluate the bit error rate
      totErr = totErr + BitErrs;
      num = num + N; 
      disp(['+++ ' num2str(totErr) '/' num2str(maxNumErrs) ' errors. '...
          num2str(num) '/' num2str(maxNum) ' bits. Projected error rate = '...
          num2str(totErr/num, '%10.1e') '. +++']);
  end 
  BER(i) = totErr/num; % Y-axis for plot
end
% ======================================================================= %
% End
% ======================================================================= %

%A_BER_uc = BER;
%C_BER_s1_uc = BER;
%C_BER_s2_uc = BER;
%C_BER_s3_uc = BER;
figure(2)
semilogy(EbN0,BER,'b*-')
xlabel('E_b/N_0 [dB]')
ylabel('BER')
ylim([1e-4 1])
title('Simulated Bit Error Rate')
legend('Uncoded')

%%%%%%%%%%%%%%%%%%%%%% Support Functions %%%%%%%%%%%%%%%%%%%%

function x_tx = symbol_mapper(u,const)
    bpsymb = log2(length(const));
    m = buffer(u, bpsymb)'; % Group bits into bits per symbol (rows correspond to one symbol's bits)
    m_idx = bit2int(m',bpsymb)+1; % Bits to symbol index
    x_tx = const(m_idx); % Look up symbols using the indices
end

function y_rx = add_awgn_noise(x_tx, EbN0,i,M)
    Lx = length(x_tx); % Length of transmitted vector x_tx
    Es = sum(abs(x_tx).^2)/(Lx); % Calculate symbol energy for x_tx
    EbN0_lin = 10^(EbN0(i)/10); % Convert EbN0 to linear scale
    SNR = EbN0_lin*log2(M); % SNR_lin = Es/N0 = Eb/N0*log2(M)
    N0 = Es./SNR; % Noise spectral density N0 (inf for /0)
    if isreal(x_tx)
        n_sigma = sqrt(N0); % St.dev. for AWGN noise (real x_tx)
        n = n_sigma*randn(1,Lx); % Real noise
    else
        n_sigma = sqrt(N0/2); % St.dev. for AWGN noise (complex x_tx)
        n = n_sigma*(randn(1,Lx)+1j*randn(1,Lx)); % Complex noise
    end
    y_rx = x_tx+n; % Received signal (after channel/noise)
end
% Hello! Here is some information on how to run the code : - )
%
% In 'project_coded.m' coded transmission can be simulated by specifying 
% the encoder, constellaion and receiver and running the script. Each run 
% plots the BER vs. EbN0 such that it can be viewed, but to save data and 
% plot multiple systems together the variable 'BER' can be manually saved 
% and plotted here. Because the simulations take time (approx 4h in total)  
% the simulated BER data is saved in 'SimDataBER.mat' which can be loaded  
% and plotted here. In 'project_uncoded.m' the constellation can be 
% specified and uncoded transmission simulated. The script 'upper_bound.m'
% was used to compute the upper bounds for the soft receivers. To use it
% the trellis must be specified (see comment). The variable for plot is 
% 'Pb_soft' which has to be plotted with its corresponding EbN0. The script
% 'distance_capaity.m' was used to calculate distance to capacity.

load('SimDataBER.mat'); % Load saved simulation data here to plot below :)

%%

close all
EbN0 = -1:10;
EbN0_ub = 0:10;
firebrick = [178,34,34]/255;
crimson = [220,20,60]/255;
forest_green = [34,139,34]/255;
lime_green = [50,205,50]/255;
dark_orange = [255,140,0]/255;
gold = [255,215,0]/255;

figure(1)
semilogy(EbN0,A_BER_uc,'x-','Color',firebrick,'Linewidth',1); hold on; % Uncoded, QPSK
semilogy(EbN0,A_BER_hd,'^-','Color',dark_orange,'Linewidth',1); hold on; % Hard decoding, QPSK
semilogy(EbN0,A_BER_sd,'d-','Color',forest_green,'Linewidth',1); hold on; % Soft decoding, QPSK
semilogy(EbN0_ub,A_BER_sd_ub,'.-','Color',lime_green,'Linewidth',1); hold on; % Upper bound (SD)
xlabel('$E_b/N_0$ [dB]','Interpreter','latex','FontSize',14); ylabel('BER','Interpreter','latex','FontSize',14); grid on; xlim([-1 9]); ylim([1e-4 1]);
title('Simulated Bit Error Rate','Interpreter','latex','FontSize',14)
legend('Uncoded, $\mathcal{X}_{\mathrm{QPSK}}$','Hard, $\mathcal{E}_2$, $\mathcal{X}_{\mathrm{QPSK}}$','Soft, $\mathcal{E}_2$, $\mathcal{X}_{\mathrm{QPSK}}$','Soft, $\mathcal{E}_2$, Upper bound','Interpreter','latex','FontSize',14)

figure(2)
semilogy(EbN0,B_BER_e1,'x-','Color',firebrick,'Linewidth',1); hold on; % Encoder 1, QPSK
semilogy(EbN0_ub,A_BER_e1_ub,'+-','Color',crimson,'Linewidth',1); hold on; % Upper bound (SD)
semilogy(EbN0,B_BER_e2,'^-','Color',forest_green,'Linewidth',1); hold on; % Encoder 2, QPSK
semilogy(EbN0_ub,A_BER_e2_ub,'v-','Color',lime_green,'Linewidth',1); hold on; % Upper bound (SD)
semilogy(EbN0,B_BER_e3,'d-','Color',dark_orange,'Linewidth',1); hold on; % Encoder 3, QPSK
semilogy(EbN0_ub,A_BER_e3_ub,'s-','Color',gold,'Linewidth',1); hold on; % Upper bound (SD)
semilogy(EbN0,A_BER_uc,'k.-','Linewidth',1); hold on; % Uncoded, QPSK
xlabel('$E_b/N_0$ [dB]','Interpreter','latex','FontSize',14); ylabel('BER','Interpreter','latex','FontSize',14); grid on; xlim([-1 9]); ylim([1e-4 1]);
title('Simulated Bit Error Rate','Interpreter','latex','FontSize',14)
legend('Soft, $\mathcal{E}_1$, $\mathcal{X}_{\mathrm{QPSK}}$','Soft, $\mathcal{E}_1$, Upper Bound','Soft, $\mathcal{E}_2$, $\mathcal{X}_{\mathrm{QPSK}}$','Soft, $\mathcal{E}_2$, Upper Bound','Soft, $\mathcal{E}_3$, $\mathcal{X}_{\mathrm{QPSK}}$','Soft, $\mathcal{E}_3$, Upper Bound','Uncoded, $\mathcal{X}_{\mathrm{QPSK}}$','Interpreter','latex','FontSize',14)

figure(3)
semilogy(EbN0,C_BER_s1_uc,'x-','Color',firebrick,'Linewidth',1); hold on; % BPSK, Uncoded
semilogy(EbN0,C_BER_s1_sd,'+-','Color',crimson,'Linewidth',1); hold on; % BPSK, Encoder 3
semilogy(EbN0,C_BER_s2_uc,'^-','Color',forest_green,'Linewidth',1); hold on; % QPSK, Uncoded
semilogy(EbN0,C_BER_s2_sd,'v-','Color',lime_green,'Linewidth',1); hold on; % QPSK, Encoder 3
semilogy(EbN0,C_BER_s3_uc,'d-','Color',dark_orange,'Linewidth',1); hold on; % AMPM, Uncoded
semilogy(EbN0,C_BER_s3_sd,'s-','Color',gold,'Linewidth',1); hold on; % AMPM, Encoder 4
xlabel('$E_b/N_0$ [dB]','Interpreter','latex','FontSize',14); ylabel('BER','Interpreter','latex','FontSize',14); grid on; xlim([-1 10]); ylim([1e-4 1]);
title('Simulated Bit Error Rate','Interpreter','latex','FontSize',14)
legend('Uncoded, $\mathcal{X}_{\mathrm{BPSK}}$','Soft, $\mathcal{E}_3$, $\mathcal{X}_{\mathrm{BPSK}}$','Uncoded, $\mathcal{X}_{\mathrm{QPSK}}$','Soft, $\mathcal{E}_3$, $\mathcal{X}_{\mathrm{QPSK}}$','Uncoded, $\mathcal{X}_{\mathrm{AMPM}}$','Soft, $\mathcal{E}_4$, $\mathcal{X}_{\mathrm{AMPM}}$','Interpreter','latex','FontSize',14)


%R = 1/2; EbN0 = 4.33; % S1
%R = 1  ; EbN0 = 4.28; % S2
%R = 2  ; EbN0 = 6.87; % S3

EbN0_lin=10^(EbN0/10);

C_awgn_d_r = log10(1+EbN0_lin*R*2)/2;
C_awgn_d_i = log10(1+EbN0_lin*R);

distance_cap_r = 10*log10(abs(C_awgn_d_r-EbN0_lin)) % [dB]
distance_cap_i = 10*log10(abs(C_awgn_d_i-EbN0_lin)) % [dB]

% S1: [3.85] / 3.69 dB from capacity (real/imag)
% S2: 3.57 / [3.25] dB from capacity (real/imag)
% S3: 6.24 / [5.84] dB from capacity (real/imag)
